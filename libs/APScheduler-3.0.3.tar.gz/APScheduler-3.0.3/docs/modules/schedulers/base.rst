:mod:`apscheduler.schedulers.base`
==================================

.. automodule:: apscheduler.schedulers.base

API
---

.. autoclass:: BaseScheduler
    :members:
