ConfigurablePluginManager
=========================

.. automodule:: yapsy.ConfigurablePluginManager
   :members:
   :undoc-members:   

