========================
IMultiprocessChildPlugin
========================

.. toctree::
   :maxdepth: 2

.. automodule:: yapsy.IMultiprocessChildPlugin
   :members:
   :undoc-members:
