IPlugin
=======

.. automodule:: yapsy.IPlugin
   :members:
   :undoc-members:   

