IPluginLocator
==============

.. automodule:: yapsy.IPluginLocator
   :members:
   :undoc-members:   
