=======================
MultiprocessPluginProxy
=======================

.. toctree::
   :maxdepth: 2

.. automodule:: yapsy.MultiprocessPluginProxy
   :members:
   :undoc-members:
