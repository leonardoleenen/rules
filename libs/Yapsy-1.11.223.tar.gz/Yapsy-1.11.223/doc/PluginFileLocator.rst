PluginFileLocator
=================

.. automodule:: yapsy.PluginFileLocator
   :members:
   :undoc-members:   
