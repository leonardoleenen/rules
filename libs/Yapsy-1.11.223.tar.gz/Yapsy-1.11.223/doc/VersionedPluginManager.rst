VersionedPluginManager
======================

.. automodule:: yapsy.VersionedPluginManager
   :members:
   :undoc-members:   

