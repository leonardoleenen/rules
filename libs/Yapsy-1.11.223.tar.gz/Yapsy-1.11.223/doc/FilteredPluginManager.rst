FilteredPluginManager
=====================

.. automodule:: yapsy.FilteredPluginManager
   :members:
   :undoc-members:   

