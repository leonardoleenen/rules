=============
PluginManager
=============

.. toctree::
   :maxdepth: 2


.. automodule:: yapsy.PluginManager
   :members:
   :undoc-members:   

