from flask import Blueprint,Flask, current_app, jsonify, render_template, request, url_for, redirect, flash, session, make_response, abort
from flask_cors import cross_origin
from functools import wraps
import urlparse
import httplib2 as http
import urllib
import os
import uuid
import json
import redis
from pymongo import MongoClient
import ldap_service 
import fnmatch

from tld import get_tld

try:
    from urlparse import urlparse
except ImportError:
    from urllib.parse import urlparse


security = Blueprint('security', "instance_manager")

def token_required(func=None):
    def _decorate(function):
        @wraps(function)
        def wrapped_function(*args, **kwargs):
            token=request.headers.get("Authorization")
            if request.headers.get("Authorization") is None:
                current_app.logger.error("Acceso denegado: No provee token. Conexion desde {0} ".format(request.remote_addr))
                return jsonify(success=False,msg="Lo sentimos pero debe indicar el token para acceder a los servicios o bien su token ha caducado"),428

            return function(*args, **kwargs)

        return wrapped_function

    if func:
        return _decorate(func)

    return _decorate


def only_production(func=None):
    def _decorate(function):
        @wraps(function)
        def wrapped_function(*args, **kwargs):
            if current_app.config["DEV_MODE"]!=True:
                return jsonify(success=False,msg="Lo sentimos, pero no se pueden crear tokens en un modo de aplicacion que no sea development" )

            return function(*args, **kwargs)
    
        return wrapped_function

    if func:
        return _decorate(func)
        
    return _decorate

def secure_service(func=None,anonymous=False):
    def _decorate(function):

        @wraps(function)
        def wrapped_function(*args, **kwargs):
            token=request.headers.get("Authorization")

            if not valid_token(token):
                return jsonify(success=False,msg="Lo sentimos pero debe indicar el token para acceder a los servicios o bien su token ha caducado"),428

            if not access_granted(token):
                return jsonify(success=False,msg="Lo sentimos pero no tiene permisos para acceder a este recurso"),403
            
            return function(*args, **kwargs)
        return wrapped_function

    if func:
        return _decorate(func)

    return _decorate 


def valid_token(token):
    if token is None:
        current_app.logger.error("Acceso denegado: No provee token. Conexion desde {0} ".format(request.remote_addr))
        return False

    current_app.logger.debug("Conexion desde: {0} utilizando el token: {1}".format(request.remote_addr,token))
    r = redis.StrictRedis(host='localhost', port=6379, db=0)
    result=r.get(token)

    if result is None:
        current_app.logger.error("Acceso denegado. Intentando acceder a un recurso con un token no valido. Token provisto: " + token)
        return False

    return True

def access_granted(token):
    # check if SERVICE PROTECTION is activated, if it's not, grant access to the user
    if not current_app.config.get('SERVICE_PROTECTION'):
        current_app.logger.debug("SERVICE_PROTECTION no definido en el CFG, o en False. No se verificaran permisos de acceso a los servicios")
        return True

    # Get the USER_PROFILES_SERVICES_MATRIX in the CFG
    matrix = current_app.config.get('USER_PROFILES_SERVICES_MATRIX')

    # Kick if the USER_PROFILES_SERVICES_MATRIX is not defined in the CFG
    if not matrix:
        current_app.logger.error("USER_PROFILES_SERVICES_MATRIX no definido en el CFG")
        return False

    # Search for the requested resource in the matrix
    requested_resource = None
    for resource in matrix:
        if fnmatch.fnmatch(resource['path'], request.path):
            requested_resource = resource
            break

    # Kick if the requested resource is not in the CFG Matrix
    if requested_resource is None:
        current_app.logger.error("El path al que se quiere acceder no coincide con ninguno de los paths de los resources definidos en USER_PROFILES_SERVICES_MATRIX")
        return False

    # GET Redis user data by token
    r = redis.StrictRedis(host='localhost', port=6379, db=0)
    user = json.loads(r.get(token))

    # LOGGED USER'S PROFILES
    profile_ids = [user_profile['profile_id'] for user_profile in user["user_profiles"]]
    # LOGGED USER'S ROLES
    rol_ids = [user_roles['rol_id'] for user_roles in user["roles"]]

    # REQUIRED PROFILES
    requested_profiles = requested_resource.get("user_profiles")
    # REQUIRED ROLES
    requested_roles = requested_resource.get("user_roles")

    # Check if there's a match between the required profiles and the user profiles
    profiles_match = len(filter(lambda x:x in requested_profiles,profile_ids))>0

    # If there's a match
    if profiles_match:
        if requested_roles:
            # The resource is also protected by rol
            if len(filter(lambda x:x in requested_roles,rol_ids))>0:
                # Both, the profiles and the roles have a match
                return True
        else:
            # The resource is only protected by profile
            return True

    return False

@security.route("/security/test")
@cross_origin(headers=['Content-Type'])
@only_production
def test():
    return jsonify(success=True,mgs="funciona")


@security.route("/security/token/create/one_shoot",methods=['POST'])
@cross_origin(headers=['Content-Type'])
@only_production
def create_one_shoot_token():
 
    '''
    Create one shoot token                 
    '''
    payload=''
    if request.data != None:
        payload=json.loads(request.data)
    
    token = str(uuid.uuid4())

    organization_id = ''
    if 'organization_id' in payload:
        organization_id = payload['organization_id']
    
    msg = {"uid":"DEV_USER",
            "cn":"Developer User",
            "email":"dev_user@moorea.io",
            "token":token,
            "one_shoot":True,
            "user_profiles":["Administrador", "Operador"],
            "roles":["cn=Design", "cn=Developer"],
            "payload":payload,
            "organization_id" : organization_id
        }


    r = redis.StrictRedis(host='localhost', port=6379, db=0)
    r.set(token,json.dumps(msg))

    return jsonify(success=True,result={"token":token,"payload":payload} )


@security.route("/security/token/create_and_redirect",methods=["GET"])
@cross_origin(headers=['Content-Type'])
def create_token_and_redirect():
    
    goto = request.args.get('goto')
    organization_id = request.args.get('organization_id')
    organization = {"organization_id": organization_id, "organization_description": organization_id}

    r = redis.StrictRedis(host='localhost', port=6379, db=0)
    token = str(uuid.uuid4())
    msg = {
        "uid":"WEBUSER",
        "cn":"Anonymous User",
        "email":"anonymous@moorea.io",
        "token":token,
        "one_shoot":True,
        "user_profiles":[{"profile_id":"OPERADOR", "profile_description":"Operador"}],
        "roles":[{"rol_id":"WEB","rol_description":"Web"}],
        "organization" : organization,
        "payload":{"organization": organization}
    }

    r.set(token,json.dumps(msg))

    TTL_KEY_WEBUSER=300


   
    if current_app.config.get("TTL_KEY_WEBUSER") is not None:
        TTL_KEY_WEBUSER = current_app.config.get("TTL_KEY_WEBUSER") 

    r.expire(token,TTL_KEY_WEBUSER)


    redirect_to = redirect(goto)
    response = current_app.make_response(redirect_to)

    if "localhost" in goto:
        domain = ".localhost"
    else:
        domain = get_tld(goto)

    response.set_cookie("token_imanager",value=token,domain=domain)

    return response,302



@security.route("/security/token/create",methods=["POST"])
@cross_origin(headers=['Content-Type'])
def create_token():
    '''
    Create a fake token given a fake sign.
    This service will be disabled on producction ENVS. Tokens will be created by auth server.  
    '''

    payload=json.loads(request.data)
    token = str(uuid.uuid4())
    
    r = redis.StrictRedis(host='localhost', port=6379, db=0)

    # Get the USER_DEV_MODE in the CFG
    msg = current_app.config.get('USER_DEV_MODE')
    if msg == None:
        msg = {
            "uid":"DEV_USER",
            "cn":"Developer User",
            "email":"dev_user@moorea.io",
            "token":token,
            "one_shoot":False,
            "user_profiles":[{"profile_id":"ADMINISTRADOR", "profile_description":"Administrador"}, {"profile_id":"OPERADOR","profile_description":"Operador"}],
            "roles":[{"rol_id":"DESIGN","rol_description":"Design"}, {"rol_id":"DEVELOPER","rol_description":"Developer"}],
            "organization" : {"organization_id": "0079_000", "organization_description": "Dev Org"},
            "filter" : {"filter_id": "DEFAULT", "filter_description": "Default"},
            "payload":payload
        }

    if request.cookies.get('moorea_auth') != None:
        headers_virgilio = {'Authorization':current_app.config['KEY_SSO']}

        target = urlparse( current_app.config['URL_SSO'] + "/get_user_info/" + request.cookies.get('moorea_auth'))
        method = 'GET'
        h = http.Http(disable_ssl_certificate_validation=True)
        response, content = h.request(target.geturl(), method, '')


        sso_token_info=json.loads(content)
        user_info=ldap_service.get_user_data(sso_token_info['result']['userid'])

        msg['uid']=sso_token_info['result']['userid']
        msg['email']=user_info['mail']
        msg['cn']=user_info['cn']

        query ={
            "only_fields":[],
            "query": "id:{2} AND application:{0} AND userid:{1}".format(current_app.config['APPLICATION_ID'],sso_token_info['result']['userid'], payload['enrollment_id'])       
        }

        target = urlparse(current_app.config["VIRGILIO_URL"] + "/enrollments/search")
        method = 'POST'
        h = http.Http(disable_ssl_certificate_validation=True)
        response, content = h.request(target.geturl(), method, json.dumps(query), headers_virgilio)
        result = json.loads(content)

        new_roles=[]
        new_user_profiles=[]

        for enroll  in result['result']['hits']:
            new_roles= [x for x in enroll['_source']['data']['rol']]

        for enroll  in result['result']['hits']:
            new_user_profiles= [x for x in enroll['_source']['data']['user_profiles']]

        msg['roles']=new_roles
        msg['user_profiles']= new_user_profiles

        if enroll['_source']['data'].get('organization'):
            msg['organization'] = enroll['_source']['data']['organization']
        else:
            msg['organization'] = {'organization_id':enroll['_source']['data']['organization_id'], 'organization_description': enroll['_source']['data']['organization_description']}
        
        if enroll['_source']['data'].get('filter'):
            msg['filter'] = enroll['_source']['data']['filter']
    
    else:
        if not current_app.config['DEV_MODE']:
            msg = payload

    r.set(token,json.dumps(msg))


    # Verify is TTL KEYS is set. Else set default value 

    TTL_KEY_WEBUSER=300
    TTL_KEY_BACKOFFICEUSER=1800
    
    if current_app.config.get("TTL_KEY_WEBUSER") is not None:
        TTL_KEY_WEBUSER = current_app.config.get("TTL_KEY_WEBUSER") 


    if current_app.config.get("TTL_KEY_BACKOFFICEUSER") is not None:
        TTL_KEY_BACKOFFICEUSER = current_app.config.get("TTL_KEY_BACKOFFICEUSER") 

    r.expire(token,TTL_KEY_BACKOFFICEUSER)

    return jsonify(success=True,result={"token":token,"payload":payload} )

@security.route("/security/user/get_roles",methods=["GET"])
@cross_origin(headers=['Content-Type'])
def user_get_roles():
    token=request.headers.get("Authorization")
    if request.headers.get("Authorization") is None:
            current_app.logger.error("Acceso denegado: No provee token. Conexion desde {0} ".format(request.remote_addr))
            return jsonify(success=False,msg="Lo sentimos pero debe indicar el token para acceder a los servicios o bien su token ha caducado"),428

    result = get_token()
    return jsonify(success=True,data=result)

# SE REMUEVE EL TOKEN REQUIRED PORQUE EN EL CASO DE VERIFICAR MAIL NO TIENE TOKEN Y LO USA EN EL EXECUTE TASK WITH ACTION BACK
# @token_required
def get_token():
    try:
        r = redis.StrictRedis(host='localhost', port=6379, db=0)

        if request.headers.get("Authorization") != None:
            token = request.headers.get("Authorization")
        else:
            token = session['token_id']

        return json.loads(r.get(token))
    except Exception,ex:
        current_app.logger.error(ex)
        return jsonify(success=False,msg="Lo sentimos pero debe indicar el token para acceder a los servicios o bien su token ha caducado"),428
@security.route("/security/rxf/matrix",methods=["GET"])
@cross_origin(headers=['Content-Type'])
@token_required
def get_available_modules():
    token=request.headers.get("Authorization")
    r = redis.StrictRedis(host='localhost', port=6379, db=0)
    user=json.loads(r.get(token))
    current_app.logger.debug(user)
    matrix = current_app.config["USER_PROFILES_MODULES_MATRIX"]
    current_app.logger.debug(matrix)
    profile_ids = [user_profile['profile_id'] for user_profile in user["user_profiles"]]
    current_app.logger.debug(profile_ids)
    available_modules = list(set([module for module, module_profiles in matrix for profile in profile_ids if profile in module_profiles]))
    current_app.logger.debug(available_modules)
    if len(available_modules)==0:
        return jsonify(success=True,msg="Lo sentimos pero no posee permisos para poder acceder al recurso solicitado"),403



    return jsonify(success=True,result=available_modules,msg="La operacion se ha realizado con exito")


@security.route("/security/get_organizations",methods=["GET"])
@cross_origin(headers=['Content-Type'])
def user_get_organizations():
    if request.cookies.get('moorea_auth') != None:
        # WE GET THIS ORGANIZATIONS FROM LDAP.

        headers = {'Authorization':"5b341f83-5359-412f-8a20-84e39a3a281c"}


        target = urlparse( current_app.config['URL_SSO'] + "/get_user_info/" + request.cookies.get('moorea_auth'))
        method = 'GET'
        h = http.Http(disable_ssl_certificate_validation=True)
        response, content = h.request(target.geturl(), method, '', headers)


        user_info=json.loads(content)
        #current_app.logger.debug("Informacion de Usuario: " + content)
        query ={
            "only_fields":[],
            "query": "application:{0} AND userid:{1}".format(current_app.config['APPLICATION_ID'],user_info['result']['userid'])       
        }


        target = urlparse(current_app.config["VIRGILIO_URL"] + "/enrollments/search")
        method = 'POST'
        h = http.Http(disable_ssl_certificate_validation=True)
        response, content = h.request(target.geturl(), method, json.dumps(query), headers)
        result = json.loads(content)

        if result['success']==False:
            return jsonify(success=True,msg="Lo sentimos pero no posee permisos para poder acceder a la aplicacion"),403

        if result['success']==True and result['result']['total']==0:
            return jsonify(success=True,msg="Lo sentimos pero no posee permisos para poder acceder a la aplicacion"),403

        organizations = []

        for enroll  in result['result']['hits']:
            if enroll['_source']['data'].get("organization") !=None:
                organizations.append({"organization_id":enroll['_source']['data']['organization']['organization_id'],"organization_description":enroll['_source']['data']['organization']['organization_description']})
            else:
                # PATCH to REMOVE  @deprecated. remove when arDifusion is deploy in Server Test 
                organizations.append({"organization_id":enroll['_source']['data']['organization_id'],"organization_description":enroll['_source']['data']['organization_description']})



        return jsonify(success=True,result=organizations,msg="La operacion se ha realizado con exito")


    else:
        if current_app.config['DEV_MODE']:
            organizations = [
                {"organization_id":"0079_000","organization_description":"Organizacion 1"},
                {"organization_id":"0079_000","organization_description":"Organizacion 2"}
            ]
            return jsonify(success=True,result=organizations,msg="La operacion se ha realizado con exito")
        else:
            msg={
                "url_return":current_app.config['URL_SSO'] + "/#/login?goto="  + current_app.config['URL_IMANAGER']
            }

            return jsonify(success=False,msg='Lo sentimos pero no posee credenciales validas para utilizar el servicio. Por favor genere y presente credenciales validas para poder acceder al servicio',result=msg),302


@security.route("/security/get_enrollments",methods=["GET"])
@cross_origin(headers=['Content-Type'])
def user_get_enrollments():
    if request.cookies.get('moorea_auth') != None:
        # WE GET THIS ORGANIZATIONS FROM LDAP.

        headers = {'Authorization':"5b341f83-5359-412f-8a20-84e39a3a281c"}


        target = urlparse( current_app.config['URL_SSO'] + "/get_user_info/" + request.cookies.get('moorea_auth'))
        method = 'GET'
        h = http.Http(disable_ssl_certificate_validation=True)
        response, content = h.request(target.geturl(), method, '', headers)


        user_info=json.loads(content)
        #current_app.logger.debug("Informacion de Usuario: " + content)
        query ={
            "only_fields":[],
            "query": "application:{0} AND userid:{1}".format(current_app.config['APPLICATION_ID'],user_info['result']['userid'])       
        }


        target = urlparse(current_app.config["VIRGILIO_URL"] + "/enrollments/search")
        method = 'POST'
        h = http.Http(disable_ssl_certificate_validation=True)
        response, content = h.request(target.geturl(), method, json.dumps(query), headers)
        result = json.loads(content)

        if result['success']==False:
            return jsonify(success=True,msg="Lo sentimos pero no posee permisos para poder acceder a la aplicacion"),403

        if result['success']==True and result['result']['total']==0:
            return jsonify(success=True,msg="Lo sentimos pero no posee permisos para poder acceder a la aplicacion"),403

        organizations = []

        enrollments=[x['_source']['data'] for x in result['result']['hits']]

        for enroll  in enrollments:
            #if enroll['_source']['data'].get("organization") !=None:
            #    organizations.append({"organization_id":enroll['_source']['data']['organization']['organization_id'],"organization_description":enroll['_source']['data']['organization']['organization_description']})
            if enroll.get("organization_id") !=None:
                # PATCH to REMOVE  @deprecated. remove when arDifusion is deploy in Server Test 
                organization = {"organization_id":enroll['organization_id'],"organization_description":enroll['organization_description']}
                enroll["organization"]= organization
                #organizations.append({"organization_id":enroll['_source']['data']['organization_id'],"organization_description":enroll['_source']['data']['organization_description']})



        return jsonify(success=True,result=enrollments,msg="La operacion se ha realizado con exito")


    else:
        if current_app.config['DEV_MODE']:
            enrollments = [
                    {
                      "id": "user1",
                      "userid": "DEV_USER",
                      "status": "ACTIVE",
                      "application": "appdemo",
                      "organization": {"organization_id": "0079_000", "organization_description": "Organizacion1"},
                      "filter": {"filter_id": "DEFAULT", "filter_description": "Default"},
                      "user_profiles": [{"profile_id": "ADMINISTRADOR", "profile_description": "Administrador"},{"profile_id": "OPERADOR", "profile_description": "Operador"}],
                      "rol": [{"rol_id": "ADMINISTRADOR", "rol_description": "Administrador"},{"rol_id": "OPERADOR", "rol_description": "Operador"}],
                      "enrollment_form":{}
                    },
                    {
                      "id": "user2",
                      "userid": "DEV_USER",
                      "status": "ACTIVE",
                      "application": "appdemo",
                      "organization": {"organization_id": "0079_001", "organization_description": "Organizacion2`"},
                      "filter": {"filter_id": "DEFAULT", "filter_description": "Default"},
                      "user_profiles": [{"profile_id": "ADMINISTRADOR", "profile_description": "Administrador"},{"profile_id": "OPERADOR", "profile_description": "Operador"}],
                      "rol": [{"rol_id": "ADMINISTRADOR", "rol_description": "Administrador"},{"rol_id": "OPERADOR", "rol_description": "Operador"}],
                      "enrollment_form":{}
                    }
            ]
            return jsonify(success=True,result=enrollments,msg="La operacion se ha realizado con exito")
        else:
            msg={
                "url_return":current_app.config['URL_SSO'] + "/#/login?goto="  + current_app.config['URL_IMANAGER']
            }

            return jsonify(success=False,msg='Lo sentimos pero no posee credenciales validas para utilizar el servicio. Por favor genere y presente credenciales validas para poder acceder al servicio',result=msg),302

@security.route("/security/get_organizations_and_filters",methods=["GET"])
@cross_origin(headers=['Content-Type'])
def user_get_organizations_and_filters():
    if request.cookies.get('moorea_auth') != None:
        
        # WE GET THIS ORGANIZATIONS FROM VIRGILIO.

        headers = {'Authorization':current_app.config['KEY_SSO']}


        target = urlparse( current_app.config['URL_SSO'] + "/get_user_info/" + request.cookies.get('moorea_auth'))
        method = 'GET'
        h = http.Http(disable_ssl_certificate_validation=True)
        response, content = h.request(target.geturl(), method, '', headers)


        user_info=json.loads(content)
        #current_app.logger.debug("Informacion de Usuario: " + content)
        query ={
            "only_fields":[],
            "query": "application:{0} AND userid:{1}".format(current_app.config['APPLICATION_ID'],user_info['result']['userid'])       
        }

        target = urlparse(current_app.config["VIRGILIO_URL"] + "/enrollments/search")
        method = 'POST'
        h = http.Http(disable_ssl_certificate_validation=True)
        response, content = h.request(target.geturl(), method, json.dumps(query), headers)

        try:

            result = json.loads(content)
        except Exception,ex:
            current_app.logger.exception(ex)
            current_app.logger.debug("VIRGILIO_URL: " + current_app.config["VIRGILIO_URL"]  )
            current_app.logger.debug(content)
            return jsonify(success=False,msg="Lo sentimos pero no se pudieron obtener los datos de virgilio. Para mas informacion consulte el log de sistema"),500

        if result['success']==False:
            current_app.logger.debug(result['msg'])
            return jsonify(success=True,msg="Lo sentimos pero no posee permisos para poder acceder a la aplicacion. Error: " + result['msg']),403

        if result['success']==True and result['result']['total']==0:
            return jsonify(success=True,msg="Lo sentimos pero no posee permisos para poder acceder a la aplicacion"),403

        
        enrollments = [x['_source']['data'] for x in result['result']['hits']]

        organizations = []
        for enroll  in enrollments:
            # PATCH to REMOVE  @deprecated. remove when arDifusion is deploy in Server Test
            # ----------------------------------------------------------------------------- 
            if enroll.get("organization_id") !=None:
                organization = {"organization_id":enroll['organization_id'],"organization_description":enroll['organization_description']}
                enroll["organization"]= organization
            # -----------------------------------------------------------------------------
            organizations.append(enroll["organization"])
        uniq_organizations = {v['organization_id']:v for v in organizations}.values()
        for org in uniq_organizations:
            org['filters'] = []
            for enroll in enrollments:
                if org['organization_id'] == enroll['organization']['organization_id']:
                    if not enroll.get('filter'):
                        enroll['filter'] = {"filter_id": "DEFAULT", "filter_description": "Default"}
                    enroll['filter']['enrollment_id'] = enroll['id']
                    org['filters'].append(enroll['filter'])
        current_app.logger.debug(uniq_organizations)
        return jsonify(success=True,result=uniq_organizations,msg="La operacion se ha realizado con exito")

    else:
        if current_app.config['DEV_MODE']:
            
            organizations = [ 
                {
                    'organization_id': 'sipro', 
                    'filters': [
                        {
                            'filter_description': 'Filtro1', 
                            'filter_id': 'FILTRO1',
                            'enrollment_id': "abcdefghijklmnopqrstuvwxyz"
                        }, 
                        {
                            'filter_description': 'Filtro2', 
                            'filter_id': 'FILTRO2',
                            'enrollment_id': "abcdefghijklmnopqrstuvwxyz"
                        }
                    ], 
                    'organization_description': 'Organizacion2'
                }
            ]

            return jsonify(success=True,result=organizations,msg="La operacion se ha realizado con exito")
        else:
            msg={
                "url_return":current_app.config['URL_SSO'] + "/#/login?goto="  + current_app.config['URL_IMANAGER']
            }

            return jsonify(success=False,msg='Lo sentimos pero no posee credenciales validas para utilizar el servicio. Por favor genere y presente credenciales validas para poder acceder al servicio',result=msg),302



@security.route("/security/organizations",methods=["POST"])
@cross_origin(headers=['Content-Type'])
@only_production
def organization_create():
    client = MongoClient('localhost', 27017)

    if  client.security.organizations.find(json.loads(request.data)).count(True) > 0:
        return jsonify(success=False,msg='Lo sentimos pero la organizacion que quiere crear ya existe'),422

    message=json.loads(request.data)
    message['owner']='DEV_USER'
    client.security.organizations.insert(message)
    return jsonify(success=True,msg='La operacion se ha realizado con exito')

@security.route("/security/organizations",methods=["GET"])
@cross_origin(headers=['Content-Type'])
@only_production
def organization_get_all():
    client = MongoClient('localhost', 27017)
    result=[]
    for element in client.security.organizations.find({},{"_id":False}):
        result.append(element)

    return jsonify(success=True,result=result) 

@security.route("/security/organizations/<id>",methods=["GET"])
@cross_origin(headers=['Content-Type'])
@only_production
def organization_get_by_id(id):
    client = MongoClient('localhost', 27017)
    result=[]

    for element in client.security.organizations.find({'organizacion_id':id,'owner':'DEV_USER'},{"_id":False}):
        result.append(element)

    return jsonify(success=True,result=result)

@security.route("/security/error/mirror/<code>",methods=['GET'])
@cross_origin(headers=['Content-Type'])
def error_mirror(code):
    return jsonify(success=True,msg='Se retorna con el codigo de error: ' + code),code

