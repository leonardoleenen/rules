# Indice
- [Secure Rest Services](#id-abstract)
- [Como funciona](#id-howitsworks)
- [Modo de uso](#id-use)
- [RoadMap](#id-roadmap)

<div id='id-abstract'/>
# Secure Rest Services  
SRS es un BluePrint de Flask para Python (acerca de blueprints en Flask http://flask.pocoo.org/docs/0.10/blueprints ) el cual permite agregar seguridad basada en tokens a los request enviados por el cliente. 

La topología es muy simple y sencilla: a cada uno de los servicios que se desea “proteger” se debe agregar un decorador llamado @secure_service lo que indica que ese servicio en cuestión debe y será protegido por la plataforma. El cliente en todos sus request debe enviar en el header request, en la etiqueta Authorization el token_id el cual hace referencia al token que reside fisicamente en un repositorio. Una vez que el request es enviando del cliente al server, el decorador intercepta la solicitud y realiza una serie de validaciones (que  se mencionan a continuación) para determinar la validez (o no) del llamado. Si el token es valido y vigente continua en el proceso del servicio, en caso contrario devuelve un 428 (HTTP RESPONSE) al cliente indicando que no se puede procesar la petición. De esta forma, todos los servicios “protegidos” devuelve siempre por defecto este error o un 403 en caso que las reglas de acceso y validación del token fueran disparadas. 

Este BluePrint como se menciono anteriormente esta basado en el framework de flask (http://flask.pocoo.org)  

<div id='id-howitsworks'/>
# Como funciona 
Como se menciono anteriormente el funcionamiento es muy simple: El blueprint ofrece y extiende una serie de servicios REST con mensajes JSON desde la ruta /security/* es decir, que todos los servicios que expone el blueprint (BP para abreviar) estarán disponibles desde la ruta security. Estos servicios pueden ser públicos (como el caso de la creación del token) o protegidos (como ser la consulta del usuario loqueado). 

Antes de comenzar a enviar peticiones HTTP REQUEST entre el cliente y el servidor se debe crear un token. Esta debe ser la primera actividad a realizar ya que la misma devolverá un token_id el cual luego debe ser enviado en cada request desde el cliente. La forma de hacerlo es invocando al servicio  /security/token/create en un método POST el cual devuelve los datos del token.  

> NOTA IMPORTANTE: En cada request se debe enviar el token_id en el header del REQUEST en la etiqueta Authorization ya que luego en cada invocación donde el servicio tenga el decorador @secure_service será evaluado

Luego se describirá con mayor detalle el contenido del token. 

Como se menciono anteriormente cada petición HTTP REQUEST es analizada y verificado el contenido del token. Si el token ha expirado o bien no se encuentra dentro del repositorio de tokens  el servicio devuelve un código de HTTP 428 lo cual indica que la transacción o petición debe ser segura y se debe generar un nuevo token. 

En caso que del análisis surja que no tiene permisos o alguna otra condición de seguridad arrojará un 403. 

Las reglas para la validación de cada token son especificas de la implementación si bien ya existen reglas de validación por defecto. 
 

## Caracteristicas del token 
Es importante recordar que el token (a diferencia de otras implementaciones) no se aloja en el browser sino en una memoria cache y el browser solo tiene la responsabilidad de sostener una referencia (llamada token_id). 

El token tiene al menos dos secciones: La sección principal reservado estrictamente para el componente de seguridad contiene las siguientes propiedades: 

* uid: Hace referencia al identificador del usuario del sistema de autenticación
* cn: (Common Name) hace referencia a la descripcion literal del usuario (Nombre y apellido en muchos casos) 
* email: es el email del usuario 
* one_shoot: Significa si ese token tiene una expiración de un solo uso. Esta propiedad requiere de una funcionalidad de “extracción” es decir, algún agente externo que elimine el token del repositorio. En algunas implementaciones es una buena práctica vincular los tokens con el servicio de acceso a datos, de esta forma cuando se accede al dato (ya sea para lectura o escritura) el token se elimina del repositorio. Es importante identificar que la implementación de este atributo depende directamente de cada cliente y no del BP  
* roles: Indica una lista de roles que posee el token 
* payload: (Carga Util) este atributo es completamente volatil y variable ya que es propio de cada implementación. Alli se puede guardar cualquier información que resulte util para el cliente y es importante destacar que el BP no hace ni uso ni referencia a ella. 
* organization_id: Representa el codigo de organizacion o bien la sub-vista de datos. En conjunción con el acceso a datos, el token puede segmentar la informacion de acuerdo al organization_id. 

A continuación se ejemplifica el contenido de un token: 

```
	{
		“uid”:”DEV_USER”,
    	“cn”:”Developer User”,
    	“email”:”dev_user@moorea.io”,
    	“token”:token,
    	“one_shoot”:False,
    	“roles”:[“Administrador”, “Operador”],
    	“payload”:payload,
    	“organization_id” : "anses_forms_web" 
	}
``` 







<div id='id-use'/>
# Modo de uso

El SRS requiere los siguientes componentes y dependencias: 

* Python 2.5,2.6 o 2.7
* Flask 
* Redis server


Para utilizar el SRS hay que realizar las siguientes tareas: 

1. Instalar el security_bp dentro del repositorio de librarias de python local
2. Incluir/Registrar el BP dentro de la aplicación (Flask app) 
3. Crear un archivo de configuracion y asociar el mismo a la configuración de la app 
4. Agregar el decorador @secure_service a cada uno de los servicios que deban ser protegidos 

## PASO 1: Instalación del SRS dentro del repositorio de python 

Para esta actividad hay varias maneras de hacerlo. Cualesquiera es válida siempre y cuando el modulo que utilice el componente tenga acceso. 

a)  Instalación mediante pip 
```shell
sudo pip install git+https://github.com/moorealabs/bp_secure_service.git#egg=security_bp 
```

b)  Mediante un archivo de setup 
```python
setup(
      name='app_name',
      version='1.0',
      dependency_links = ['git+https://github.com/moorealabs/bp_secure_service.git#egg=security_bp'],
      description='MyApp',
      author='team@moorea.io',
      author_email='team@moorea.io',
      url='http://www.python.org/sigs/distutils-sig/',
      install_requires=['flask','PyMongo','flask_cors','httplib2','redis','security_bp']
)
```

## PASO 2: Incluir/Registrar el BP dentro de la aplicación (Flask app) 

Dentro de la aplicación flask (donde se instancia la app) se debe incluir el siguiente codigo: 

```python
from blueprint.security_bp import security
app.register_blueprint(security)
```

De esa forma el bluprint queda disponble  bajo la ruta http://SERVER:PORT/security/* 

## PASO 3: Crear un archivo de configuracion y asociar el mismo a la configuración de la app 

El SRS se sirve de la configuración propia del app. Dicho en palabras python lee la configuración del current_app las siguientes claves: 

```python
DEV_MODE=True
ROLESxMODULES_MATRIX_SERVICE="/security/rxf/matrix"
```

La clave DEV_MODE indica si la el SRS esta funcionado en modo desarrollo, es decir, para aquellos casos que se desea probar en modo local. En breve explicaremos en detalle que significa correr la seguridad en modo local. 

La clave ROLESxMODULES_MATRIX_SERVICE indica donde reside el servicio de roles. Esta clave es importante ya que en ocaciones donde se desea implementar ya existe algun servicio de roles o bien un SSO sobre el cual se consumirán datos. El servicio actual sostiene el siguiente SLA: 
```json
{
  "msg": "La operacion se ha realizado con exito", 
  "result": [
    "certificates", 
    "services", 
    "tesauros", 
    "workflows"
  ], 
  "success": true
}
```


## PASO 4: Agregar el decorador @secure_service para proteger los servicios

Para hacer uso del SRS se debe incluir el siguiente decorador (aquí un ejemplo): 

```python
@workflow_engine.route('/test/alive')
@cross_origin(headers=['Content-Type'])
@secure_service
def is_alive():
    return "I'am alive dude"
```



<div id='id-roadmap'/>
# RoadMap 

A la versión actual y a los efectos de contar con una versión más rica en funcionalidades se deben incorporar las siguientes actividades: 

* Servicio para enviar emails con invitaciones  
* Servicio para que la persona pueda adherirse mediante una invitacion que ha sido enviada 
* Aplicar seguridad de JWT
* Verificar si el token ha sido creado con un browser especifico setear para que todos los servicios atraviesen ese token 
* Manejo de Listas negreas y listas de exclusion para pruebas cerradas.



# Licencia 

MIT	

