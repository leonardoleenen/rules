from setuptools import setup, find_packages,Command
import os



version = '0.2'


class CleanCommand(Command):
    """Custom clean command to tidy up the project root."""
    user_options = []
    def initialize_options(self):
        pass
    def finalize_options(self):
        pass
    def run(self):
        os.system('rm -vrf ./build ./dist ./*.pyc ./*.tgz ./*.egg-info')



setup(

      cmdclass={
         'clean': CleanCommand
      },
      name='security_bp',
      packages=['blueprint'],
      include_package_data=True,
      zip_safe=False, 
      version='1.0',
      description='Moorea Security Service',
      author='Leonardo G. Leenen',
      author_email='leonardo@moorea.io',
      url='http://www.python.org/sigs/distutils-sig/',
      install_requires=['flask','python-ldap','PyMongo','flask_cors','httplib2','redis']
)

