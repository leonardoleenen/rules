# Nice to Have

* Redis parameter in config file
* Token One Shot, use only once time. Implements new create token 
